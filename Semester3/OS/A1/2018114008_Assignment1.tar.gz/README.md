# Usage instructions:

## Question 1
`gcc question1.c`
`./a.out <testfile>`

## Question 2
`gcc question2.c`
`./a.out <newfile> <oldfile> <directory>`

Author: Akshat Chhajer
